console.log("loaded");
import { initEventsPage } from "./pages/events.page.js";

document.addEventListener("DOMContentLoaded", () => {
  initEventsPage();
});
