# Event Platform Frontend

Frontend-проект платформы мероприятий (events platform), реализованный на чистом **HTML, SCSS и Vanilla JavaScript**.  
Проект демонстрирует работу с модульной архитектурой, адаптивной вёрсткой и клиентской логикой фильтрации данных.

🔗 **Live demo:**  
https://rusrus0110-star.github.io/events-platform-frontend/

---

## 📌 Описание проекта

Event Platform — это интерфейс для просмотра и фильтрации мероприятий по различным параметрам:
- тип события (online / offline)
- категория
- дистанция

Проект построен без фреймворков и сборщиков, с упором на:
- чистую структуру проекта
- читаемый код
- адаптивность под мобильные устройства
- разделение ответственности (data / services / ui)

---

## ⚙️ Технологии

- **HTML5**
- **SCSS (modular structure)**
- **Vanilla JavaScript (ES6+)**
- **Git / GitHub**
- **GitHub Pages**

---

## 🗂 Структура проекта

```text
/
├── assets/
│   └── images/
│
├── js/
│   ├── data/
│   │   └── events.data.js        # источник данных
│   │
│   ├── services/
│   │   └── events.filter.js      # логика фильтрации
│   │
│   ├── ui/
│   │   ├── eventCard.js          # шаблон карточки события
│   │   └── events.render.js      # рендер списка событий
│   │
│   ├── utils/
│   │   └── date.js               # работа с датами
│   │
│   └── main.js                   # точка входа
│
├── pages/
│   └── events.html               # страница мероприятий
│
├── scss/
│   ├── base/                     # reset, variables, fonts
│   ├── components/               # cards, buttons
│   ├── layout/                   # header, footer, grid
│   ├── pages/                    # стили страниц
│   ├── responsive/               # media queries
│   └── main.scss
│
└── index.html
Ключевые особенности
🔹 Модульная архитектура JavaScript
данные отделены от логики
UI-рендеринг вынесен в отдельные модули
фильтрация реализована через сервисный слой

🔹 Адаптивная вёрстка
mobile-first подход
корректная работа на экранах от 360px
flex / grid без сторонних библиотек
🔹 Чистый SCSS

разделение на base / components / layout / pages
переменные и переиспользуемые стили
единый responsive-файл

Адаптивность

Проект протестирован на:

360px (Android)
375px (iPhone)
414px
tablet / desktop
Особое внимание уделено:
отсутствию горизонтального скролла
корректному поведению карточек и фильтров

